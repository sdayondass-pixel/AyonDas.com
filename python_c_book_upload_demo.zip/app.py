from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
import os

# Simple learning demo. For public production, add authentication and HTTPS.
BASE_DIR = Path(__file__).resolve().parent
BOOKS_DIR = BASE_DIR / "books"
BOOKS_DIR.mkdir(exist_ok=True)
ALLOWED_EXTENSIONS = {".pdf"}
MAX_BYTES = 20 * 1024 * 1024  # 20 MB

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_BYTES

def is_pdf(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS

@app.get("/")
def home():
    return jsonify({
        "message": "Book Upload API is running",
        "endpoints": {
            "list_books": "GET /books",
            "upload_book": "POST /upload with form field 'file' and optional 'title'",
            "download_book": "GET /books/<filename>"
        }
    })

@app.get("/books")
def list_books():
    items = []
    for path in sorted(BOOKS_DIR.glob("*.pdf")):
        items.append({"filename": path.name, "url": f"/books/{path.name}"})
    return jsonify(items)

@app.post("/upload")
def upload_book():
    uploaded = request.files.get("file")
    title = request.form.get("title", "").strip()

    if uploaded is None or not uploaded.filename:
        return jsonify({"error": "No file received. Send a PDF in form field 'file'."}), 400

    safe_name = secure_filename(uploaded.filename)
    if not safe_name or not is_pdf(safe_name):
        return jsonify({"error": "Only PDF files are allowed."}), 400

    # Keep the original extension and avoid overwriting an existing book.
    destination = BOOKS_DIR / safe_name
    if destination.exists():
        return jsonify({"error": "A file with this name already exists. Rename the PDF and try again."}), 409

    uploaded.save(destination)
    return jsonify({
        "message": "Book uploaded successfully",
        "title": title or Path(safe_name).stem,
        "filename": safe_name,
        "url": f"/books/{safe_name}"
    }), 201

@app.get("/books/<path:filename>")
def download_book(filename):
    safe_name = secure_filename(filename)
    if safe_name != filename or not is_pdf(safe_name):
        return jsonify({"error": "Invalid filename"}), 400
    return send_from_directory(BOOKS_DIR, safe_name, as_attachment=False)

if __name__ == "__main__":
    # Local development only; do not expose Flask's development server publicly.
    app.run(host="127.0.0.1", port=5000, debug=False)
