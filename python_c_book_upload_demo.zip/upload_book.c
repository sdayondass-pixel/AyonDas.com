/*
 * C PDF upload client using libcurl.
 * Build: gcc upload_book.c -o upload_book $(pkg-config --cflags --libs libcurl)
 * Example:
 *   ./upload_book "http://127.0.0.1:5000/upload" "python-book.pdf" "Python Beginner Book"
 *
 * This demo sends a PDF to your own Flask server.
 * Do not send private files to a server you do not trust.
 */
#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>

int main(int argc, char *argv[]) {
    if (argc < 3 || argc > 4) {
        fprintf(stderr, "Usage: %s <server-upload-url> <pdf-file> [book-title]\n", argv[0]);
        return 1;
    }

    const char *url = argv[1];
    const char *file_path = argv[2];
    const char *title = (argc == 4) ? argv[3] : "Untitled Book";

    FILE *test = fopen(file_path, "rb");
    if (!test) {
        perror("Cannot open PDF file");
        return 1;
    }
    fclose(test);

    CURLcode global_code = curl_global_init(CURL_GLOBAL_DEFAULT);
    if (global_code != CURLE_OK) {
        fprintf(stderr, "Could not initialize libcurl.\n");
        return 1;
    }

    CURL *curl = curl_easy_init();
    if (!curl) {
        fprintf(stderr, "Could not create CURL handle.\n");
        curl_global_cleanup();
        return 1;
    }

    curl_mime *form = curl_mime_init(curl);
    curl_mimepart *part = curl_mime_addpart(form);
    curl_mime_name(part, "file");
    curl_mime_filedata(part, file_path);
    curl_mime_type(part, "application/pdf");

    part = curl_mime_addpart(form);
    curl_mime_name(part, "title");
    curl_mime_data(part, title, CURL_ZERO_TERMINATED);

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_MIMEPOST, form);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 0L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 120L);

    CURLcode result = curl_easy_perform(curl);
    long status_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status_code);

    if (result != CURLE_OK) {
        fprintf(stderr, "Upload failed: %s\n", curl_easy_strerror(result));
    } else {
        printf("HTTP status: %ld\n", status_code);
        if (status_code >= 200 && status_code < 300) {
            printf("Upload request completed successfully.\n");
        } else {
            printf("Server rejected the upload. Check its response and logs.\n");
        }
    }

    curl_mime_free(form);
    curl_easy_cleanup(curl);
    curl_global_cleanup();

    return (result == CURLE_OK && status_code >= 200 && status_code < 300) ? 0 : 1;
}
