বই আপলোড ডেমো — Python + C
============================

ফাইল:
- app.py: Python Flask upload server
- upload_book.c: libcurl দিয়ে PDF upload client
- requirements.txt: Python dependency
- books/: আপলোড করা PDF ফাইল এখানে জমা হবে

শুরু করার নিয়ম (কম্পিউটারে)
---------------------------

১) Python 3 ইনস্টল করো।
২) এই ফোল্ডারে terminal/command prompt খোলো।
৩) চালাও:
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   pip install -r requirements.txt
   python app.py

৪) একই কম্পিউটারের browser-এ খোলো:
   http://127.0.0.1:5000/
   বইয়ের তালিকা:
   http://127.0.0.1:5000/books

৫) Python দিয়ে একটি PDF আপলোড (নতুন terminal-এ):
   curl -F "title=Python Book" -F "file=@python-book.pdf" http://127.0.0.1:5000/upload

C client:
-----------
C compiler এবং libcurl development package লাগবে।
Linux/macOS:
   gcc upload_book.c -o upload_book $(pkg-config --cflags --libs libcurl)
   ./upload_book http://127.0.0.1:5000/upload python-book.pdf "Python Book"

Windows-এ libcurl সেটআপ compiler অনুযায়ী আলাদা; Code::Blocks/Dev-C++-এ libcurl না থাকলে এই C example compile হবে না।

নমুনা বই:
---------
এই ZIP-এ কপিরাইটমুক্ত নিজস্ব লেখা ৩টি ছোট নমুনা PDF যোগ করার জায়গা রাখা হয়েছে না; নিজের বৈধ PDF books/ ফোল্ডারে রাখো এবং upload endpoint দিয়ে পাঠাও।
তুমি চাইলে নিজস্ব নোট/পাবলিক-ডোমেইন বই PDF হিসেবে যোগ করতে পারো।

নিরাপত্তা:
----------
এটি শেখার জন্য local demo; এতে Admin login নেই। এটিকে সরাসরি public internet-এ প্রকাশ কোরো না।
Public server-এর আগে authentication, admin authorization, HTTPS, rate limits, virus/file validation, storage quotas এবং secure object storage যোগ করতে হবে।
GitHub Pages Python/C server চালাতে পারে না; এই Flask app-কে আলাদা server/hosting-এ চালাতে হবে।
